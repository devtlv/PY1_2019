<!---Tags=["if","else"]--->

# Exercices Conditionals

### Exercice 1
1. Ask a number to the user, and save it to a variable. 
2.  Check if the variable  is an even number
* If yes, display:  "x is an even number’. Where x is the actual number of the user   
* If no, display "x is not an even number’. Where x is the actual number of the user   

### Exercise 2
1. Create 2 variables, x and y =. Each of them has a different numeric value
2. Write an if/else statement that display the bigger number  
 
### Exercice 3 : The World Translator 
 
1. Ask the user which language he speaks 
2. Create a few conditions : 
* If he speaks French : display “Bonjour” 
* If he speaks English : display “Hello” 
* If he speaks Hebrew : display “Shalom” 
* If he doesn’t speak none of these 3 languages: display “😊” 
 
### Exercice 4 : The Average 
 
1. Ask the user to give you a grade. Save it in a variable  
2. Ask the user to give you a coefficient. Save it in a variable  
3. Create an empty array called `userGrade`, and push inside the grade of the user  
4. Create an empty array called `userCoefficient`, and push inside the coefficient of the user  
5. Check if the variable `userGrade` and `userCoefficient` are empty : 
* If `userGrade` is empty ask again the user to give you a grade  
* If `userCoefficient`  is empty ask again the user to give you coefficient 
* If not, then calculate the average ((Grade*Coefficient)/number of grades )
 
### Exercice 5 : The Grade Assigner: Use Switch Case

1. Ask the user for his grade 
* If the score is bigger than 90, console.log ‘A’
* If the score is between 80 and 90, console.log ‘B’
* If the score is between 70 and 80, console.log ‘C’
* If the score is lower than 70, console.log ‘D’
