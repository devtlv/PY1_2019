<!---Tags=["array"]--->

# Exercices Data Types

### Exercice 1 : 

`var people = ["Greg", "Mary", "Devon", "James"]`
1. Using a loop, iterate through this array and display all of the people.
2. Write the command to remove "Greg" from the array.
3. Write the command to replace "James" by “Jason” in the array.
4. Write the command to add your name to the end of the array.
5. Using a loop, iterate through this array and after console.log-ing "Mary", exit from the loop.
6. Write the command to make a copy of the array using slice. The copy should NOT include "Mary" or your name.
7. 	Write the command that gives the indexOf where "Mary" is located.
8. Write the command that gives the indexOf where "Foo" is located (this should return -1).
9. 	Write a variable `last` which value is the last element of the array 

### Exercice 2
`var age = [20,5,12,43,98,55]`
1. console.log the sum of all the elements of the array
2. console.log just the *even* numbers
3. Bonus: Return the largest number of the array


