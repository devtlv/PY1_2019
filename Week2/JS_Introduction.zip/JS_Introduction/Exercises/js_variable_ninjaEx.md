<!---Tags=["string"]--->

# Exercises Ninja JS

### Exercice 1
`var me = [“my”,”favorite”,”color”,”is”,”blue”]`
1. Write a simple JavaScript program to join all elements of the following array into a string. 

### Exercice 2:  MixUp
1. Create two strings,
2. Create a variable which value is the concatenation of the two strings (separated by a space) slicing out and swapping the first 2 characters of each. 

Example :
```
var str1 = 'mix', var str2 = ‘pod' 
var newWord should be equal to 'pox mid'
```

### Exercice 3 : Verbing
1. Create a string 
2. If the length of this string is at least 3, it should add 'ing' to its end, unless it already ends in 'ing', in which case it should add 'ly' instead. 
3.	If the string length is less than 3, it should leave it unchanged. 

For example:
  The string is : 'swim' , your program should console.log : 'swimming'
  The string is : ‘swimming', your program should console.log : 'swimmingly'
  The string is : 'go' your program should console.log : 'go'

### Exercice 4 : Not Bad
1. Create a string that has the word “not” and “bad” inside
2. Create another variable that should find the first appearance of the substring 'not' and 'bad'.
3. If the 'bad' follows the 'not', then it should replace the whole 'not'...'bad' substring with 'good' than console.log the result.
4. If it doesn't find 'not' and 'bad' in the right sequence (or at all), just console.log the original sentence.

For example:
  Your string is : 'This dinner is not that bad!', the result is : 'This dinner is good!'
  Your string is : 'This movie is not so bad!' the result is : 'This movie is good!'
  Your string is : 'This dinner is bad!' the result is : 'This dinner is bad!'




    


