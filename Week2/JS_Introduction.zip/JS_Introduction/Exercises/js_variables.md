<!---Tags=["strings","array"]--->

# Exercices _ Variables

## Exercise1

1. Write variables and give them values:    
* `addressNumber`
* `addressStreet`
* `country`
2. Write a variable `global_address`, and concatenate inside, the variables that we created above in order to create a sentence    
    Example : global_address should display « I live in BenYehuda 5, in Israel »     
3. Display global_address     
    
## Exercise 2   
1.	Create a numerically indexed table named `pets`, like this  
`[‘cat’,’dog’,’fish’,’rabbit’,’cow’]`
2. 	Display dog   
3. 	Add a horse to the array 
4. Remove the rabbit from the array
5. 	Display the array length   
   
### Exercise 3   
1. Create a variable `newDog`that is equal to “Chihuahua” 
2. Check and display how many letters are in `newDog`
3.	Display the `newDog` variable in uppercase and then in lowercase 
4. 	Check if the variable `newDog` equals to “Chihuahua”  
* if it equals to “Chihuahua”, display ‘I LOVE Chihuahua, it’s my favorite *dog*’. Where dog is the item in the array pets created in Exercice2  
* else, console.log “I dont care, I prefer CATS”  

### Exercise 4
1. Store your birth year in a variable. 
2. Store a future year in a variable. 
3. Calculate your possible ages for that year based on the stored values. 
4. Display : "I will be NN  in YYYY", substituting the values. 



