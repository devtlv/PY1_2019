# Exercice Gold JS

### Exercise 1: 
1. Write a JS program to print alphabet pattern 'A'. with stars * 
Donc look for the answer on the internet  
Hint : Use Row and Column  
